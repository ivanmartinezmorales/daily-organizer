# Sunday Funday

## Todo Items
- [ ] Finish app
- [ ] Add location
- [ ] Add CoreData
- [ ] Add ImagePickerView 


The UI is basically done, all that is left is adding in the functionality at this point

